require 'core.options'
require 'plugins.lazy'
require 'core.keybindings'
require 'core.commands'
