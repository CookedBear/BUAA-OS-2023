local options = {
    disable_netrw = true,
    view = {
        mappings = {
            list = require('core.keybindings').tree,
        },
    },
    actions = {
        open_file = {
            quit_on_open = true,
            resize_window = true,
        },
    },
}

require('nvim-tree').setup(options)
