local options = {
    filetype = {
        c = 'cd $dir && gcc -g -Wall -lm $fileName -o $fileNameWithoutExt && $dir/$fileNameWithoutExt',
        cpp = 'cd $dir && g++ -g -Wall -lm $fileName -o $fileNameWithoutExt && $dir/$fileNameWithoutExt',
        lua = 'lua',
        python = 'python3 -u',
        sh = 'bash',
    },
}

require('code_runner').setup(options)
