local options = { transparent = false }

require('tokyonight').setup(options)
