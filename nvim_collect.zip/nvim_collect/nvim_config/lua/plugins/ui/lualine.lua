local options = {
    sections = { lualine_z = {} },
}

require('lualine').setup(options)
