local options = {
    ensure_installed = {
        'bash',
        'c',
        'cpp',
        'css',
        'html',
        'java',
        'javascript',
        'json',
        'latex',
        'lua',
        'markdown',
        'markdown_inline',
        'python',
        'regex',
        'tsx',
        'typescript',
        'vim',
        'yaml',
    },
    highlight = { enable = true },
    endwise = { enable = true },
    rainbow = {
        enable = true,
        extended_mode = true,
        max_file_lines = nil,
    },
}

require('nvim-treesitter.configs').setup(options)
