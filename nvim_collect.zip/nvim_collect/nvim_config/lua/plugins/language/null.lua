local null = require 'null-ls'

local options = {
    sources = {
        -- formatting
        null.builtins.formatting.clang_format,
    },
}

null.setup(options)
