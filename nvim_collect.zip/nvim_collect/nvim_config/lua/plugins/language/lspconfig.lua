local default_config = require('core.utils').setup_lsp()

local servers = {
    clangd = default_config, -- C and C++
}

for name, config in pairs(servers) do
    require('lspconfig')[name].setup(config)
end
