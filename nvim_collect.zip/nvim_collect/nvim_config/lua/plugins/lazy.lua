local plugins = {
    -- UI
    {
        'folke/tokyonight.nvim',
        branch = 'main',
        config = function() require 'plugins.ui.tokyonight' end,
    },
    {
        'glepnir/dashboard-nvim',
        dependencies = 'nvim-tree/nvim-web-devicons',
        config = function() require 'plugins.ui.dashboard' end,
    },
    {
        'akinsho/bufferline.nvim',
        event = { 'BufRead', 'BufNewFile' },
        version = 'v3.*',
        dependencies = 'nvim-tree/nvim-web-devicons',
        config = function() require 'plugins.ui.bufferline' end,
    },
    {
        'nvim-lualine/lualine.nvim',
        event = { 'BufRead', 'BufNewFile' },
        dependencies = 'nvim-tree/nvim-web-devicons',
        config = function() require 'plugins.ui.lualine' end,
    },
    {
        'lewis6991/gitsigns.nvim',
        event = { 'BufRead', 'BufNewFile' },
        config = function() require('gitsigns').setup() end,
    },
    -- Language Support
    {
        'nvim-treesitter/nvim-treesitter',
        event = { 'BufRead', 'BufNewFile' },
        build = ':TSUpdate',
        dependencies = {
            'RRethy/nvim-treesitter-endwise',
            'p00f/nvim-ts-rainbow',
        },
        config = function() require 'plugins.language.treesitter' end,
    },
    {
        'neovim/nvim-lspconfig',
        event = { 'BufRead', 'BufNewFile' },
        config = function() require 'plugins.language.lspconfig' end,
    },
    {
        'glepnir/lspsaga.nvim',
        cmd = 'Lspsaga',
        config = function() require('lspsaga').setup {} end,
    },
    {
        'jose-elias-alvarez/null-ls.nvim',
        dependencies = {
            'nvim-lua/plenary.nvim',
        },
        event = { 'BufRead', 'BufNewFile' },
        config = function() require 'plugins.language.null' end,
    },
    -- Completion
    {
        'L3MON4D3/LuaSnip',
        dependencies = 'rafamadriz/friendly-snippets',
        event = 'InsertEnter',
        config = function() require('luasnip.loaders.from_vscode').lazy_load() end,
    },
    {
        'hrsh7th/nvim-cmp',
        dependencies = {
            'onsails/lspkind.nvim',
            'saadparwaiz1/cmp_luasnip',
            'hrsh7th/cmp-nvim-lsp',
            'hrsh7th/cmp-buffer',
            'hrsh7th/cmp-nvim-lua',
            'hrsh7th/cmp-path',
            'hrsh7th/cmp-cmdline',
            'hrsh7th/cmp-calc',
            'hrsh7th/cmp-nvim-lsp-signature-help',
        },
        event = 'InsertEnter',
        config = function() require 'plugins.completion.cmp' end,
    },
    {
        'windwp/nvim-autopairs',
        event = 'InsertEnter',
        config = function() require 'plugins.completion.autopairs' end,
    },
    -- Tools
    {
        'nvim-tree/nvim-tree.lua',
        cmd = 'NvimTreeToggle',
        dependencies = 'nvim-tree/nvim-web-devicons',
        config = function() require 'plugins.tools.tree' end,
    },
    { 'famiu/bufdelete.nvim', cmd = 'Bdelete' },
    {
        'abecodes/tabout.nvim',
        dependencies = 'nvim-treesitter',
        event = 'InsertEnter',
        config = function() require('tabout').setup() end,
    },
    {
        'nvim-telescope/telescope.nvim',
        dependencies = {
            'nvim-lua/plenary.nvim',
            {
                'nvim-telescope/telescope-fzf-native.nvim',
                build = 'make',
            },
        },
        cmd = 'Telescope',
        config = function() require 'plugins.tools.telescope' end,
    },
    {
        'numToStr/Comment.nvim',
        event = { 'BufRead', 'BufNewFile' },
        config = function() require('Comment').setup() end,
    },
    {
        'CRAG666/code_runner.nvim',
        dependencies = 'nvim-lua/plenary.nvim',
        cmd = { 'RunCode', 'RunFile', 'RunProject' },
        config = function() require 'plugins.tools.runner' end,
    },
}
local options = {
    defaults = { version = '*' },
    concurrency = 8,
    performance = {
        disabled_plugins = {
            '2html_plugin',
            'getscript',
            'getscriptPlugin',
            'gzip',
            'logipat',
            'netrw',
            'netrwPlugin',
            'netrwSettings',
            'netrwFileHandlers',
            'matchit',
            'tar',
            'tarPlugin',
            'rrhelper',
            'spellfile_plugin',
            'vimball',
            'vimballPlugin',
            'zip',
            'zipPlugin',
            'tutor',
            'rplugin',
            'syntax',
            'synmenu',
            'optwin',
            'compiler',
            'bugreport',
            'ftplugin',
        },
    },
}

vim.opt.rtp:prepend(vim.fn.stdpath 'data' .. '/lazy/lazy.nvim')
local present, lazy = pcall(require, 'lazy')
if not present then
    require('core.utils').bootstrap()
else
    lazy.setup(plugins, options)
    vim.cmd [[colorscheme tokyonight]]
end
