-- duplicate parametes
local keymap = vim.keymap.set
local opts = { noremap = true, silent = true }

-- set leader key
vim.g.mapleader = ' '
vim.g.maplocalleader = ' '

-- plugins' keybindings
local M = {}

-- nvim-tree
keymap('n', '<leader>e', '<cmd>NvimTreeToggle<CR>', opts)
M.tree = {
    { key = { '<CR>', 'o', '<2-LeftMouse>' }, action = 'edit' },
    -- open file with split window
    { key = 'v', action = 'vsplit' },
    { key = 'h', action = 'split' },
    -- change status of hidden files
    { key = '<C-h>', action = 'toggle_dotfiles' }, -- Hide (dotfiles)
    -- file operation
    { key = '<F5>', action = 'refresh' },
    { key = 'a', action = 'create' },
    { key = 'x', action = 'remove' },
    { key = 'r', action = 'rename' },
    { key = 'd', action = 'cut' },
    { key = 'y', action = 'copy' },
    { key = 'p', action = 'paste' },
}

-- bufferline
keymap('n', '<C-h>', '<cmd>BufferLineCyclePrev<CR>', opts)
keymap('n', '<C-l>', '<cmd>BufferLineCycleNext<CR>', opts)
keymap('n', '<C-w>', '<cmd>Bdelete!<CR>', opts)

-- telescope
keymap('n', '<C-p>', '<cmd>Telescope find_files<CR>', opts)
keymap('n', '<C-f>', '<cmd>Telescope live_grep<CR>', opts)
M.telescope = {
    i = {
        ['<C-j>'] = 'move_selection_next',
        ['<C-k>'] = 'move_selection_previous',
        ['<Down>'] = 'move_selection_next',
        ['<Up>'] = 'move_selection_previous',
        ['<C-n>'] = 'cycle_history_next',
        ['<C-p>'] = 'cycle_history_prev',
        ['<C-c>'] = 'close',
        ['<C-u>'] = 'preview_scrolling_up',
        ['<C-d>'] = 'preview_scrolling_down',
    },
}

-- lsp
-- Formatting
M.lsp = function(mapbuf, bufopts)
    mapbuf('n', '<space>f', function() vim.lsp.buf.format { async = true } end, bufopts)
end

-- Lsp finder
keymap('n', 'gh', '<cmd>Lspsaga lsp_finder<CR>', opts)
-- Code action
keymap({ 'n', 'v' }, '<leader>ca', '<cmd>Lspsaga code_action<CR>', opts)
-- Rename
keymap('n', 'gr', '<cmd>Lspsaga rename<CR>', opts)
-- Peek definition
keymap('n', 'gd', '<cmd>Lspsaga peek_definition<CR>', opts)
-- Diagnostic
keymap('n', '<leader>sl', '<cmd>Lspsaga show_line_diagnostics<CR>', opts)
keymap('n', '<leader>sc', '<cmd>Lspsaga show_cursor_diagnostics<CR>', opts)
keymap('n', '<leader>sb', '<cmd>Lspsaga show_buf_diagnostics<CR>', opts)
keymap('n', '[e', '<cmd>Lspsaga diagnostic_jump_prev<CR>', opts)
keymap('n', ']e', '<cmd>Lspsaga diagnostic_jump_next<CR>', opts)
-- Outline
keymap('n', '<leader>o', '<cmd>Lspsaga outline<CR>', opts)
-- Hover doc
keymap('n', 'K', '<cmd>Lspsaga hover_doc<CR>', opts)
-- Callhierarchy
keymap('n', '<Leader>ci', '<cmd>Lspsaga incoming_calls<CR>')
keymap('n', '<Leader>co', '<cmd>Lspsaga outgoing_calls<CR>')
-- Float terminal
keymap({ 'n', 't' }, '<leader>t', '<cmd>Lspsaga term_toggle<CR>')

M.cmp = function(cmp)
    return {
        ['<C-k>'] = cmp.mapping.select_prev_item(),
        ['<C-j>'] = cmp.mapping.select_next_item(),
        ['<CR>'] = cmp.mapping.confirm { select = false },
    }
end

-- Code Runner
keymap('n', '<leader>r', '<cmd>RunCode<CR>', opts)

return M
