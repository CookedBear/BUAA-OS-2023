require'cmp'.register_source('calc', require'cmp_calc'.new())

